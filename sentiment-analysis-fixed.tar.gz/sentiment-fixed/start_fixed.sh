#!/bin/bash
echo '=== 舆情分析系统部署脚本 ==='
echo '检查Python环境...'
python3 --version
echo '创建虚拟环境...'
python3 -m venv venv
echo '激活虚拟环境...'
source venv/bin/activate
echo '升级pip...'
pip install --upgrade pip
echo '安装依赖包...'
pip install -r requirements.txt
echo '创建必要目录...'
mkdir -p data exports logs
echo '启动应用...'
echo '访问地址: http://localhost:8000'
uvicorn main:app --host 0.0.0.0 --port 8000
